<?php get_header();

	//GETTING META VALUES...
	$lesson_settings = get_post_meta($post->ID, '_lesson_settings', true);
	$page_layout = !empty($lesson_settings['layout']) ? $lesson_settings['layout'] : 'content-full-width';
	$private_lesson = !empty($lesson_settings['private-lesson']) ? $lesson_settings['private-lesson'] : '';

	$show_sidebar = $show_left_sidebar = $show_right_sidebar =  false;
	$sidebar_class = "";

	switch ( $page_layout ) {
		case 'with-left-sidebar':
			$page_layout = "page-with-sidebar with-left-sidebar";
			$show_sidebar = $show_left_sidebar = true;
			$sidebar_class = "secondary-has-left-sidebar";
		break;

		case 'with-right-sidebar':
			$page_layout = "page-with-sidebar with-right-sidebar";
			$show_sidebar = $show_right_sidebar	= true;
			$sidebar_class = "secondary-has-right-sidebar";
		break;

		case 'both-sidebar':
			$page_layout = "page-with-sidebar page-with-both-sidebar";
			$show_sidebar = $show_right_sidebar	= $show_left_sidebar = true;
			$sidebar_class = "secondary-has-both-sidebar";
		break;

		case 'content-full-width':
		default:
			$page_layout = "content-full-width";
		break;
	}

	$ts = get_post_meta($post->ID, '_lesson_settings', true);
	
	if ( $show_sidebar ):
		if ( $show_left_sidebar ): ?>
			<!-- Secondary Left -->
			<section id="secondary-left" class="secondary-sidebar <?php echo $sidebar_class;?>"><?php get_sidebar( 'left' );?></section><?php
		endif;
	endif;?>

	<!-- ** Primary Section ** -->
	<section id="primary" class="<?php echo $page_layout;?>">
    <?php 
	
	$dt_lesson_course = get_post_meta ($post->ID, "dt_lesson_course",true);
	$s2_level = "access_s2member_ccap_cid_{$dt_lesson_course}";
	
	if ( current_user_can($s2_level) || ($private_lesson == '') ){
		
		if( have_posts() ): while( have_posts() ): the_post();
			$the_id = get_the_ID(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class('dt-sc-lesson-single'); ?>>
				<h2><?php the_title(); ?> </h2>
								
	
				<div class="lesson-metadata">
	
					<?php 
						$duration = $lesson_settings['lesson-duration'];
						if($duration > 0) {
							$hours = floor($duration/60); 
							$mins = $duration % 60; 
							if($hours == 0) {
								$duration = $mins . __(' mins ', 'dt_themes'); 				
							} elseif($hours == 1) {
								$duration = $hours .  __(' hour ', 'dt_themes') . $mins . __(' mins ', 'dt_themes'); 				
							} else {
								$duration = $hours . __(' hours ', 'dt_themes') . $mins . __(' mins ', 'dt_themes'); 				
							}
						}
					?>
	
					<p><i class="fa fa-tags"> </i> <?php the_terms($post->ID,'lesson_complexity'); ?> </p>
					<p><i class="fa fa-clock-o"> </i> <?php echo $duration; ?> </p>
					<p> <i class="fa fa-book"> </i>
						<?php
						$dt_lesson_course = get_post_meta ( $the_id, "dt_lesson_course",true);
						if(isset($dt_lesson_course) && $dt_lesson_course != '') {
							$course_data = get_post($dt_lesson_course);
							echo '<a href="'.get_permalink($course_data->ID).'">'.$course_data->post_title.'</a>';	
						}
						?>
					</p>
					
				</div>
				
				<div class="dt-sc-clear"></div>
				<div class="dt-sc-hr-invisible-small"></div>
				<div class="entry">
						<?php the_content(); ?>        
				</div>    
				
											
				<?php 
				$lesson_video = get_post_meta($the_id, 'lesson-video', true);
				if(isset($lesson_video) && $lesson_video != '') { ?>
					<div class="dt-sc-hr-invisible"></div>
                    <h4 class="border-title"><?php _e('Lesson Intro Video', 'dt_themes'); ?><span></span></h4>
					<div class="lesson-video"><?php echo wp_oembed_get( $lesson_video ); ?></div>
				<?php } ?>
				
				
				
				<div class="dt-sc-hr-invisible-medium"></div>
				<?php
				$lesson_teacher = get_post_meta ( $id, "lesson-teacher",true);
				if($lesson_teacher != '') {
					$teacher_data = get_post($lesson_teacher);
					$ts = get_post_meta($teacher_data->ID, '_teacher_settings', true);
				?>
				<h5 class="border-title"><?php echo __('Staff', 'dt_themes') ?><span></span></h5>
				<div class="column dt-sc-one-third space first">
					<div class="team-thumb">
						<?php if( has_post_thumbnail($teacher_data->ID) ):
								echo get_the_post_thumbnail($teacher_data->ID, 'full');
							  else:
								echo '<img src="http://placehold.it/500x500&text=Image" alt="" />';
						endif; ?>
					</div>
				</div>
				<div class="column dt-sc-two-third space">
					<h5><?php echo $teacher_data->post_title; ?></h5>
					<div class="clear"> </div>
                    <ul class="teachers-details">
                        <li> <?php echo __('Role', 'dt_themes'); ?> : <?php echo $ts['role']; ?> </li>
                        <li> <?php echo __('Website', 'dt_themes'); ?> : <?php echo '<a href="'.$ts['url'].'">'.$ts['url'].'</a>'; ?> </li>
                        <li> <?php echo __('Experience', 'dt_themes'); ?> : <?php echo $ts['exp']; ?> </li>
                        <li> <?php echo __('Specialist in', 'dt_themes'); ?> : <?php echo $ts['special']; ?> </li>
                    </ul>
					<a class="dt-sc-button small" href="<?php echo get_permalink($teacher_data->ID); ?>"><?php echo __('Read More', 'dt_themes'); ?></a>
				</div>
				<div class="dt-sc-hr-invisible-small"></div>
				<?php
				}
				?>
				
				<?php
				edit_post_link(__('Edit', 'dt_themes'), '<span class="edit-link">', '</span>' );
				if(!dttheme_option('general', 'disable-lessons-comment')) { comments_template('', true); } 
				?>
				
			</article>
			<?php 
		endwhile; endif;
				
	} else {
		echo '<div class="dt-sc-warning-box">'.__('This lesson is priceable, you have to purchase the course <a href="'.get_permalink($dt_lesson_course).'">'.get_the_title($dt_lesson_course).'</a> to view this lesson.', 'dt_themes').'</div>';
		echo '<a href="'.get_permalink($dt_lesson_course).'" target="_self"  class="dt-sc-button small">'.__('Purchase Now', 'dt_themes').'</a>';
	}
	?>
    
	</section><!-- ** Primary Section End ** --><?php

	if ( $show_sidebar ):
		if ( $show_right_sidebar ): ?>
			<!-- Secondary Right -->
			<section id="secondary-right" class="secondary-sidebar <?php echo $sidebar_class;?>"><?php get_sidebar( 'right' );?></section><?php
		endif;
	endif;?>
<?php get_footer(); ?>